This is an alternative setup structure to support multiple cores.

For general examples on standard solr configuration, see the "solr" directory.